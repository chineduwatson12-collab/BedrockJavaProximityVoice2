package dev.openai.proximityvoice;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

public final class ProximityVoicePlugin extends JavaPlugin {
    private HttpClient http;
    private String endpoint;
    private String room;
    private String token;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        FileConfiguration cfg = getConfig();
        endpoint = cfg.getString("voice-server-url", "");
        room = cfg.getString("room", "change-this-room");
        token = cfg.getString("bridge-token", "");
        int interval = Math.max(10, cfg.getInt("position-interval-ticks", 20));
        http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();

        if (endpoint.isBlank() || endpoint.contains("YOUR-VOICE-SERVER")) {
            getLogger().warning("Set voice-server-url in plugins/BedrockJavaProximityVoice/config.yml.");
        }
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, this::publishPositions, 20L, interval);
        getLogger().info("Enabled. Coordinates will be published to the configured voice bridge.");
    }

    private void publishPositions() {
        // Bukkit world/player access is normally main-thread-only. Snapshot coordinates on main thread.
        Bukkit.getScheduler().runTask(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                Location loc = player.getLocation();
                World world = player.getWorld();
                String json = "{\"room\":\"" + esc(room) + "\",\"name\":\"" + esc(player.getName())
                    + "\",\"x\":" + loc.getX() + ",\"y\":" + loc.getY() + ",\"z\":" + loc.getZ()
                    + ",\"dimension\":\"" + esc(world.getKey().toString()) + "\"}";
                post(json);
            }
        });
    }

    private void post(String json) {
        if (endpoint.isBlank() || endpoint.contains("YOUR-VOICE-SERVER") || token.isBlank()) return;
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(endpoint))
                .timeout(Duration.ofSeconds(4))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();
            http.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .thenAccept(response -> {
                    if (response.statusCode() >= 400) getLogger().warning("Voice bridge returned HTTP " + response.statusCode());
                })
                .exceptionally(ex -> { getLogger().fine("Voice bridge request failed: " + ex.getMessage()); return null; });
        } catch (Exception ex) {
            getLogger().warning("Could not publish voice position: " + ex.getMessage());
        }
    }

    private static String esc(String value) {
        return value.replace("\\\\", "\\\\\\\\").replace("\"", "\\\\\"")
            .replace("\\n", "").replace("\\r", "");
    }
}
