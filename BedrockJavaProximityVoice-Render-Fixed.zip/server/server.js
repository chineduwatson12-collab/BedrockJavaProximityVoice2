const express = require("express");
const http = require("http");
const path = require("path");
const { WebSocketServer, WebSocket } = require("ws");

const PORT = Number(process.env.PORT || 8080);
const BRIDGE_TOKEN = process.env.BRIDGE_TOKEN || "";
const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "..", "client")));
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/signal" });
const peers = new Map();
const positions = new Map();

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function roomMembers(room) {
  return [...peers.entries()].filter(([, p]) => p.room === room);
}
function broadcastRoom(room, obj, except) {
  for (const [ws, p] of peers) if (p.room === room && ws !== except) send(ws, obj);
}

wss.on("connection", (ws) => {
  const id = Math.random().toString(36).slice(2) + Date.now().toString(36);
  peers.set(ws, { id, room: null, name: "Player" });
  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    const peer = peers.get(ws);
    if (!peer) return;
    if (msg.type === "join") {
      const room = String(msg.room || "").trim().slice(0, 64);
      const name = String(msg.name || "Player").trim().slice(0, 32);
      if (!room) return send(ws, { type: "error", message: "Enter a room name." });
      if (peer.room) broadcastRoom(peer.room, { type: "peer-left", id: peer.id }, ws);
      peer.room = room; peer.name = name || "Player";
      send(ws, { type: "joined", id, room, peers: roomMembers(room).filter(([other]) => other !== ws).map(([, p]) => ({ id: p.id, name: p.name })) });
      broadcastRoom(room, { type: "peer-joined", id: peer.id, name: peer.name }, ws);
      const roomPos = positions.get(room);
      if (roomPos) send(ws, { type: "positions", players: Object.fromEntries(roomPos) });
      return;
    }
    if (!peer.room) return;
    if (["offer", "answer", "ice"].includes(msg.type)) {
      const target = [...peers.entries()].find(([, p]) => p.id === msg.to && p.room === peer.room);
      if (target) send(target[0], { ...msg, from: peer.id, fromName: peer.name });
    } else if (msg.type === "leave") {
      const room = peer.room;
      broadcastRoom(room, { type: "peer-left", id: peer.id }, ws);
      peer.room = null;
    }
  });
  ws.on("close", () => {
    const peer = peers.get(ws);
    if (peer?.room) broadcastRoom(peer.room, { type: "peer-left", id: peer.id }, ws);
    peers.delete(ws);
  });
});

app.get("/health", (_req, res) => res.json({ ok: true, service: "bedrock-java-proximity-voice", connectedClients: peers.size }));

app.post("/bridge/position", (req, res) => {
  if (!BRIDGE_TOKEN) return res.status(503).json({ error: "Set BRIDGE_TOKEN on the server before enabling the position bridge." });
  if (req.get("authorization") !== `Bearer ${BRIDGE_TOKEN}`) return res.status(401).json({ error: "unauthorized" });
  const { room, name, x, y, z, dimension } = req.body || {};
  if (![room, name].every(v => typeof v === "string" && v.length > 0 && v.length < 64)) return res.status(400).json({ error: "invalid room/name" });
  if (![x, y, z].every(v => Number.isFinite(Number(v)) && Math.abs(Number(v)) < 3e7)) return res.status(400).json({ error: "invalid coordinates" });
  const roomName = room.slice(0, 64), playerName = name.slice(0, 32);
  let roomPos = positions.get(roomName);
  if (!roomPos) positions.set(roomName, roomPos = new Map());
  roomPos.set(playerName, { x:Number(x), y:Number(y), z:Number(z), dimension:String(dimension || "overworld").slice(0,64), at:Date.now() });
  broadcastRoom(roomName, { type:"position", name:playerName, x:Number(x), y:Number(y), z:Number(z), dimension:String(dimension || "overworld").slice(0,64) });
  res.json({ ok:true });
});

server.listen(PORT, "0.0.0.0", () => console.log(`Voice server listening on http://0.0.0.0:${PORT}`));
